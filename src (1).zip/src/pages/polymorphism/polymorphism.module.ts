import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PolymorphismPage } from './polymorphism';

@NgModule({
  declarations: [
    PolymorphismPage,
  ],
  imports: [
    IonicPageModule.forChild(PolymorphismPage),
  ],
})
export class PolymorphismPageModule {}
