import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { NumbersclassPage } from './numbersclass';

@NgModule({
  declarations: [
    NumbersclassPage,
  ],
  imports: [
    IonicPageModule.forChild(NumbersclassPage),
  ],
})
export class NumbersclassPageModule {}
